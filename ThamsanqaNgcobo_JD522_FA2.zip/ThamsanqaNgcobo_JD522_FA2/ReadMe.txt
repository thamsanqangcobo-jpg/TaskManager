# Task Manager

A simple Java User Interface that allows users to create, view, and manage daily tasks.  
The project includes features such as task categorization, filtering, and exporting task data to a CSV file.

---

## 🧠 Features
- Add, edit, and delete tasks
- Categorize tasks using HashMap
- Filter tasks by category or keyword
- Display file properties (size, creation date)
- Export tasks to a CSV file using Java NIO
- GUI built manually using Swing components

---

## ⚙️ Technologies Used
- Java (JDK 17+)
- Swing (for GUI)
- Collections Framework (`ArrayList`, `HashMap`)
- Java I/O and NIO

---

## 🚀 How to Run
1. Open the project in an IDE like Netbeans IDEA or Eclipse.
2. Make sure you have Java JDK 17 or higher installed.
3. Run the main class file (e.g., `TaskManager.java` or `Main.java`).
4. The GUI window will open, allowing you to manage your tasks.


## 🧑‍💻 Author
**Thami Ngcobo**  
IT Student @ CTU Training Solutions

---
